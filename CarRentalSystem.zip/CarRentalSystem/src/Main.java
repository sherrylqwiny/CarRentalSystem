/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sherrylochieng
 */
public class Main {
    public static void main(String[] args) {
        // Initialize the rental agency
        RentalAgency rentalAgency = new RentalAgency();
        Car car = new Car("KAA123A", "Toyota Corolla", 1000.0);
        Customer customer = new Customer("C001", "Sherryl Ochieng", "DL123456");
        
        // Add car to rental agency
        rentalAgency.addCar(car);
        
        // Register customer
        rentalAgency.registerCustomer(customer);
        
        // Rent a car
        rentalAgency.rentCar(customer, car);
        System.out.println(customer.getName() + " rented " + car.getModel());
        
        // Simulate some delay (e.g., renting for 3 days)
        // Rent return process
        rentalAgency.returnCar(customer, car);
        System.out.println(customer.getName() + " returned " + car.getModel());

        // Output total cost for the rental
        Rental rental = customer.getRentalHistory().get(0);  // Get the first rental
        System.out.println("Total cost for rental: " + rental.getTotalRentalCost());
    }
}


