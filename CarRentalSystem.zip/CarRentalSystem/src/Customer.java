/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sherrylochieng
 */
import java.util.ArrayList;

public class Customer {
    private String customerId;
    private String name;
    private String drivingLicenseNumber;
    private ArrayList<Rental> rentalHistory;

    // Constructor
    public Customer(String customerId, String name, String drivingLicenseNumber) {
        this.customerId = customerId;
        this.name = name;
        this.drivingLicenseNumber = drivingLicenseNumber;
        this.rentalHistory = new ArrayList<>();
    }

    // Getters
    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getDrivingLicenseNumber() {
        return drivingLicenseNumber;
    }

    public ArrayList<Rental> getRentalHistory() {
        return rentalHistory;
    }

    // Method to rent a car
    public void rentCar(Car car, Rental rental) {
        if (car.isAvailable()) {
            car.rentCar();
            rentalHistory.add(rental);
            System.out.println(name + " rented " + car.getModel());
        } else {
            System.out.println("Car is not available.");
        }
    }

    // Method to return a car
    public void returnCar(Rental rental) {
        rental.getCar().returnCar();
        rental.setReturnDate(); // Assume current date for simplicity
        System.out.println(name + " returned " + rental.getCar().getModel());
    }
}

