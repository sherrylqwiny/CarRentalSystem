/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sherrylochieng
 */
import java.time.LocalDate;

public class Rental {
    private Car car;
    private Customer customer;
    private LocalDate rentalDate;
    private LocalDate returnDate;
    private double totalRentalCost;

    // Constructor
    public Rental(Car car, Customer customer, LocalDate rentalDate) {
        this.car = car;
        this.customer = customer;
        this.rentalDate = rentalDate;
        this.returnDate = null; // Not yet returned
        this.totalRentalCost = 0.0;
    }

    // Getters
    public Car getCar() {
        return car;
    }

    public Customer getCustomer() {
        return customer;
    }

    public LocalDate getRentalDate() {
        return rentalDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    // Set return date and calculate cost
    public void setReturnDate() {
        this.returnDate = LocalDate.now();
        calculateRentalCost();
    }

    // Method to calculate the rental cost based on rental days
    public void calculateRentalCost() {
        if (returnDate != null) {
            long daysRented = rentalDate.until(returnDate).getDays();
            totalRentalCost = daysRented * car.getRentalPricePerDay();
        }
    }

    public double getTotalRentalCost() {
        return totalRentalCost;
    }
}
