/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sherrylochieng
 */
import java.util.ArrayList;
import java.time.LocalDate;


public class RentalAgency {
    private ArrayList<Car> availableCars;
    private ArrayList<Customer> customers;
    private ArrayList<Rental> activeRentals;

    // Constructor
    public RentalAgency() {
        this.availableCars = new ArrayList<>();
        this.customers = new ArrayList<>();
        this.activeRentals = new ArrayList<>();
    }

    // Add a new car to the agency
    public void addCar(Car car) {
        availableCars.add(car);
    }

    // Remove a car from the agency
    public void removeCar(Car car) {
        availableCars.remove(car);
    }

    // Register a new customer
    public void registerCustomer(Customer customer) {
        customers.add(customer);
    }

    // Rent a car to a customer
    public void rentCar(Customer customer, Car car) {
        if (car.isAvailable()) {
            Rental rental = new Rental(car, customer, LocalDate.now());
            activeRentals.add(rental);
            customer.rentCar(car, rental);
        } else {
            System.out.println("Car is not available for rent.");
        }
    }

    // Return a car from a customer
    public void returnCar(Customer customer, Car car) {
        for (Rental rental : activeRentals) {
            if (rental.getCar().equals(car) && rental.getCustomer().equals(customer)) {
                customer.returnCar(rental);
                activeRentals.remove(rental);
                break;
            }
        }
    }
}

