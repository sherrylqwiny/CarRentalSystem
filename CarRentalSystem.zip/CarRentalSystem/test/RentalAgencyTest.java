/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sherrylochieng
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;


public class RentalAgencyTest {
    private RentalAgency rentalAgency;
    private Car car1;
    private Car car2;
    private Customer customer;

    @BeforeEach
    public void setUp() {
        rentalAgency = new RentalAgency();
        car1 = new Car("KAA123A", "Toyota Corolla", 1000.0);
        car2 = new Car("KBB456B", "Honda Civic", 1200.0);
        customer = new Customer("C001", "John Doe", "DL123456");

        rentalAgency.addCar(car1);
        rentalAgency.addCar(car2);
        rentalAgency.registerCustomer(customer);
    }

    @Test
    public void testAddCar() {
        assertTrue(rentalAgency != null);
        assertTrue(car1.isAvailable());
        assertTrue(car2.isAvailable());
    }

    @Test
    public void testRegisterCustomer() {
        assertEquals("John Doe", customer.getName());
        assertEquals("C001", customer.getCustomerId());
    }

    @Test
    public void testRentCar() {
        rentalAgency.rentCar(customer, car1);
        assertFalse(car1.isAvailable());  // After renting, car should not be available
    }

    @Test
    public void testReturnCar() {
        rentalAgency.rentCar(customer, car1);
        assertFalse(car1.isAvailable());  // Car is rented out
        rentalAgency.returnCar(customer, car1);
        assertTrue(car1.isAvailable());  // After returning, car should be available
    }

    @Test
    public void testRentalTransaction() {
        rentalAgency.rentCar(customer, car2);
        assertFalse(car2.isAvailable());  // After renting, car should not be available

        // Ensure correct transaction flow
        rentalAgency.returnCar(customer, car2);
        assertTrue(car2.isAvailable());  // After return, car should be available
    }
}

