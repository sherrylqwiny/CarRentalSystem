/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sherrylochieng
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CarTest {

    @Test
    public void testRentCar() {
        Car car = new Car("KAA123A", "Toyota Corolla", 1000.0);
        assertTrue(car.isAvailable());
        
        car.rentCar();
        assertFalse(car.isAvailable());
    }

    @Test
    public void testReturnCar() {
        Car car = new Car("KAA123A", "Toyota Corolla", 1000.0);
        car.rentCar();
        car.returnCar();
        assertTrue(car.isAvailable());
    }
}

