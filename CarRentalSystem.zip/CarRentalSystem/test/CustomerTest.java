/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sherrylochieng
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class CustomerTest {
    private Customer customer;
    private Car car;
    private Rental rental;

    @BeforeEach
    public void setUp() {
        customer = new Customer("C001", "John Doe", "DL123456");
        car = new Car("KAA123A", "Toyota Corolla", 1000.0);
        rental = new Rental(car, customer, java.time.LocalDate.now());
    }

    @Test
    public void testCustomerDetails() {
        assertEquals("C001", customer.getCustomerId());
        assertEquals("Sherryl Ochieng", customer.getName());
        assertEquals("DL123456", customer.getDrivingLicenseNumber());
    }

    @Test
    public void testRentCar() {
        customer.rentCar(car, rental);
        assertFalse(car.isAvailable());  // After renting, car should not be available
        ArrayList<Rental> rentalHistory = customer.getRentalHistory();
        assertEquals(1, rentalHistory.size()); // Customer should have 1 rental in history
    }

    @Test
    public void testReturnCar() {
        customer.rentCar(car, rental);
        customer.returnCar(rental);
        assertTrue(car.isAvailable());  // After returning, car should be available
    }
}

