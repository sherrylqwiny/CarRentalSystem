/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sherrylochieng
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

public class RentalTest {
    private Rental rental;
    private Car car;
    private Customer customer;

    @BeforeEach
    public void setUp() {
        car = new Car("KAA123A", "Toyota Corolla", 1000.0);
        customer = new Customer("C001", "John Doe", "DL123456");
        rental = new Rental(car, customer, LocalDate.now());
    }

    @Test
    public void testRentalDetails() {
        assertEquals(car, rental.getCar());
        assertEquals(customer, rental.getCustomer());
        assertEquals(LocalDate.now(), rental.getRentalDate());
        assertNull(rental.getReturnDate());  // Initially, the return date should be null
    }

    @Test
    public void testSetReturnDate() {
        rental.setReturnDate();
        assertEquals(LocalDate.now(), rental.getReturnDate());
    }

    @Test
    public void testCalculateRentalCost() {
        // Simulate a 2-day rental
        rental.setReturnDate(); // Sets the return date to today
        assertEquals(0, rental.getTotalRentalCost());  // Same day rental should have 0 cost

        // Manually set rental date to 2 days ago for testing
        rental = new Rental(car, customer, LocalDate.now().minusDays(2));
        rental.setReturnDate();
        assertEquals(2000.0, rental.getTotalRentalCost());  // 2 days * 1000/day = 2000
    }
}

